import './globals.css'

export const metadata = {
  title: 'Levam Corp Distributors',
  description: 'B2B Wholesale Distribution — Miami, FL. Apply to become an approved distributor partner.',
  keywords: 'wholesale distributor, electronics, appliances, B2B, Miami, Doral',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet" />
      </head>
      <body>{children}</body>
    </html>
  )
}
