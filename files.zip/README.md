# Levam Corp Distributors — levamcorp.com

B2B Wholesale Distribution Platform · Doral, FL 33178

## Stack
- **Framework**: Next.js 14 (App Router)
- **Database & Auth**: Supabase
- **Hosting**: Vercel
- **Styling**: CSS + Tailwind

## Configuración en 5 pasos

### 1. Clonar y instalar
```bash
npm install
```

### 2. Variables de entorno
El archivo `.env.local` ya tiene tus claves de Supabase configuradas:
```
NEXT_PUBLIC_SUPABASE_URL=https://scmyjjnrflmqquflveca.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_i70jEzFzjdOsBY5JIIWVVw_XOqu3s7O
```

### 3. Base de datos
Corre el archivo `levamcorp_supabase_schema.sql` en el SQL Editor de Supabase.
Ya está hecho ✅

### 4. Correr en local
```bash
npm run dev
```
Abre http://localhost:3000

### 5. Publicar en Vercel
1. Sube este proyecto a GitHub
2. Importa el repo en vercel.com
3. Agrega las variables de entorno en Vercel Dashboard → Settings → Environment Variables
4. Conecta el dominio levamcorp.com en Vercel → Domains
5. En Namecheap apunta los nameservers a Vercel

## Páginas incluidas

| Ruta | Descripción |
|------|-------------|
| `/` | Landing page pública |
| `/apply` | Formulario de aplicación para distribuidores |
| `/portal` | Login del portal de clientes |
| `/portal/dashboard` | Dashboard del cliente aprobado |
| `/portal/catalog` | Catálogo privado con quotes |
| `/admin` | Panel de administración (solo Levam Corp) |

## Información de la empresa (ya configurada)
- **Nombre**: Levam Corp Distributors
- **Dirección**: 6315 NW 99th Ave, Doral, FL 33178
- **Email**: partners@levamcorp.com
- **Web**: levamcorp.com

## Soporte
Construido con Claude — seguir desarrollando en claude.ai
